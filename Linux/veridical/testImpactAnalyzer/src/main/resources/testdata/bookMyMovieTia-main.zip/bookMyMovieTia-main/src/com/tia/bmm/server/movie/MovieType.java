package com.tia.bmm.server.movie;

public enum MovieType {
	ENGLISH,
    HINDI;
}
