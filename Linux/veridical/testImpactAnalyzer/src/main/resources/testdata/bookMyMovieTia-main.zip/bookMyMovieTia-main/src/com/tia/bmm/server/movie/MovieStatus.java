package com.tia.bmm.server.movie;

public enum MovieStatus {
	NOW_SHOWING,
    MOVIE_NOT_AVAILABLE,
    UPCOMING;
}
