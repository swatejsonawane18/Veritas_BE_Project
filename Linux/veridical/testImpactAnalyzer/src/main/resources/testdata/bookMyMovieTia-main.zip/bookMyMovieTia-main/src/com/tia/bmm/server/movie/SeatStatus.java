package com.tia.bmm.server.movie;

public enum SeatStatus {
	SEAT_BOOKED,
    SEAT_NOT_BOOKED;
}
