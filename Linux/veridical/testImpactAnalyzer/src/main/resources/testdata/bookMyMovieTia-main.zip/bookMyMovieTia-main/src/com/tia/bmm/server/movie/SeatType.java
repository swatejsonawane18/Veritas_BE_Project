package com.tia.bmm.server.movie;

public enum SeatType {
	SILVER,
    GOLD,
    PLATINUM;
}
